# encoding=utf-8
import jieba
import jieba.posseg as pseg

jieba.enable_paddle()
words = pseg.cut("人大监督的目的是督促和支持一府两院依法行政和公正司法", use_paddle=True)
for word, flag in words:
    print('%s %s' % (word, flag))


