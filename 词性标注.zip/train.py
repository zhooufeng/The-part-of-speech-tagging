#encoding=utf-8

#隐马尔科夫模型词性标注训练

tagger = HMMPOSTagger()

#训练：
tagger.train(corpus)
#预测
print(', '.join(tagger.tag(word_model)))
#构造词法分析器：
hmmanalyzer = AbstractLexicalAnalyzer(PerceptronSegenter(),tagger)


#感知机词法分析器训练

trainer = POSTrainer()

#训练
trainer.train(corpus, POS_MODEL)
#加载：
tagger = PerceptronPOSTagger(POS_MODEL)
#预测：
print('. '.join(tagger.tag(word_model)))
#构造词法分析器：
panalyzer = AbstractLexicalAnalyzer(PerceptronSegenter(),tagger)

#条件随机场训练

tagger1 = CRFPOSTTagger(None)

#训练：
tagger1.train(corpus, POS_MODEL)
#加载：
tagger1 = CRFPOSTTagger (POS_MODEL)
#预测：
print('. '.join(tagger1.tag(word_model)))
#构造词法分析器：
ranalyzer = AbstractLexicalAnalyzer(PerceptronSegenter(),tagger)

#自定义词性
CustomDictionary.insert("苹果","手机品牌1")
CustomDictionary.insert("iPhone X","手机型号1")
analyzer = PerceptronLexicalAnalyzer()
analyzer.enableCustomDictionaryForcing(True)
analyzer.analyze("你们苹果iPhone X保修吗？") #你们/r 苹果/手机品牌 iPhone X/手机型号 保修/v 吗/y ？/w
analyzer,analyze("多吃苹果有益健康") #多/ad 吃/v 苹果/手机品牌 有益健康/i

#模型测试
#隐马尔科夫模型词性标注：
hmmanalyzer.analyze(sentence)
#感知机词法分析器训练词性标注：
panalyzer.analyze(sentence)
#条件随机场训练词性标注：
ranalyzer.analyze(sentence)





